Content Plugin addarticiletojshopping version 1.0.0  is a free software which is developed by
KWProductions Co.
The license is GNU/GPLv3
It is written for joomla 3.x, joomla 4 alpha and betta, 

There are some conditions to work with this plugin :
1- The plugin is designed to work with com_k2 and com_jshopping, it relies on both
2-The user creates the same category structure both in k2 and jshopping, the name must be the same and children in different
 categories can not have the same name, names must be unique. In pro version, I shall add a plugin
 in such a way that as soon as a user creates a category in k2, the same would be created in jshopping automatically 
3-The user must create two extra fields in K2, first one must be for a price under the name field: K2ExtraField_1,
 second for a short description of the article, the name field K2ExtraField_2,
 In pro version it will be done automatically as soon as the main plugin is uploaded and enabled.
4-I used the manufacturer_id field of table #__jshopping products to add userid of the article writer in k2
5-I used the product_ean field(product code) of table #__jshopping_products to add article id in K2 to the related record
It is easy to alter the table and add these new fields to it but I would rather the integrity of
 the table products in jshopping remain the same.
6-The plugin works with all languages but category names must be the same as I mentioned before,
 for example, if a user writes an article in French and the name of the category in k2 is: La Science, 
 in jshopping this category with the same name must be created.
7-In Pro versions an article writer could upload a zip file with related 
images but this one is basic, the user must type or copy and paste the article with related images.

you may download the extension @:
https://www.extensions.kwproductions121.com/myplugins/add-artucke-to-jshopping.html
In case of any problem contact me at:
webarchitect@kwproductions121.com
https://github.com/KianWilliam/addarticletojshopping.git
long live science.
